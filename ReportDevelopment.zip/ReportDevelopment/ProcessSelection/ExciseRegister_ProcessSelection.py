import os
from datetime import datetime
from django.http import FileResponse
from django.shortcuts import render
import os.path
from django.views.static import serve
from GetDataFromDB import ExciseRegister_GetDataFromDB
Exceptions=""

def ExciseRegister(request):
    LSName = datetime.now()
    LSstring = str(LSName)
    LSFileName = LSstring[0:4] + LSstring[5:7] + LSstring[8:10] + LSstring[11:13] + LSstring[14:16] + LSstring[17:19] + LSstring[20:]
    LSFileName = "ExciseRegister" + LSFileName
    save_name = os.path.join(os.path.expanduser("~"), LSFileName)
    alpp.c = alpp.canvas.Canvas(save_name + ".pdf")

    LSCompany=request.GET.getlist('unit')
    LSChallanType=request.GET.getlist('chllantype')
    LSParty=request.GET.getlist('party')
    LSCharges=request.GET.getlist('charges')
    LSAllCompanies=request.GET.getlist('allcomp')
    LSAllChallanTypes=request.GET.getlist('allaccount')
    LSAllParties=request.GET.getlist('allparty')
    LSAllCharges=request.GET.getlist('allcharges')
    LSDepartment=request.GET.getlist('dept')
    LSItemType=request.GET.getlist('itemtype')
    LSChallanCategory=request.GET.getlist('') 
    LSAllDepartments=request.GET.getlist('alldept')
    LSAllItemTypes=request.GET.getlist('allitemtype')
    LSAllChallanCategories=request.GET.getlist('challancat')
    LDStartDate=request.GET.getlist('startdate')
    LDEndDate=request.GET.getlist('enddate')
    LSReportType=request.GET.getlist('year')
    LSLotType=request.GET.getlist('allchallancat')
    ExciseRegister_GetDataFromDB.ExciseRegister_GerData(LSCompany,LSChallanType,LSParty,LSCharges,LSAllCompanies,LSAllChallanTypes,
    LSAllParties,LSAllCharges,LSDepartment,LSItemType,LSChallanCategory,LSAllDepartments,LSAllItemTypes,LSAllChallanCategories,LDStartDate,
    LDEndDate,LSLotType)

    if LSReportType==1:
        LSFileName="ExciseRegisterDepartmentWise"+LSFileName
        save_name = os.path.join(os.path.expanduser("~"), LSFileName)
        pdfrpt.c = pdfrpt.canvas.Canvas(save_name + ".pdf")
        PurReg.ExciseRegister_PrintPDF(LSCompany,LSChallanType,LSParty,LSCharges,LSAllCompanies,LSAllChallanTypes,
        LSAllParties,LSAllCharges,LSDepartment,LSItemType,LSChallanCategory,LSAllDepartments,LSAllItemTypes,LSAllChallanCategories,LDStartDate,
        LDEndDate,LSLotType)
    elif LSReportType==2:
        LSFileName = "ExciseRegister_InvNoWise" + LSFileName
        save_name = os.path.join(os.path.expanduser("~"),LSFileName)
        pdfrptitem.c = pdfrptitem.canvas.Canvas(save_name + ".pdf")
        PurItemSum.ExciseRegister_InovNoWise_PrintPDF(LSCompany,LSChallanType,LSParty,LSCharges,LSAllCompanies,LSAllChallanTypes,
        LSAllParties,LSAllCharges,LSDepartment,LSItemType,LSChallanCategory,LSAllDepartments,LSAllItemTypes,LSAllChallanCategories,LDStartDate,
        LDEndDate,LSLotType)
    elif LSReportType==3:
        LSFileName = "ExciseRegister_ChallanTypeWiseItemShade" + LSFileName
        save_name = os.path.join(os.path.expanduser("~"),LSFileName)
        pdfrptcharge.c = pdfrptcharge.canvas.Canvas(save_name + ".pdf")
        PurChargeSum.ExciseRegister_ChallanTypeWiseItemShade_PrintPDF(LSCompany,LSChallanType,LSParty,LSCharges,LSAllCompanies,LSAllChallanTypes,
        LSAllParties,LSAllCharges,LSDepartment,LSItemType,LSChallanCategory,LSAllDepartments,LSAllItemTypes,LSAllChallanCategories,LDStartDate,
        LDEndDate,LSLotType)
    elif LSReportType==4:
        LSFileName="ExciseRegister_ChallanTypeWise"+LSFileName
        save_name=os.path.join(os.path.expanduser("~"),LSFileName)
        pdfrptcharge.c = pdfrptcharge.canvas.Canvas(save_name + ".pdf")
        PurChargeSum.ExciseRegister_ChallanTypeWise_PrintPDF(LSCompany,LSChallanType,LSParty,LSCharges,LSAllCompanies,LSAllChallanTypes,
        LSAllParties,LSAllCharges,LSDepartment,LSItemType,LSChallanCategory,LSAllDepartments,LSAllItemTypes,LSAllChallanCategories,LDStartDate,
        LDEndDate,LSLotType)



    #return HttpResponse(response)
    #return render(request,"ExciseRegister.html",{'GDataItemCode':views.GDataItemCode,'GDataCompanyCode':views.GDataCompanyCode,'Exception':Exceptions,'download':download})
    filepath = save_name + ".pdf"
    if not os.path.isfile(filepath):
        return render(request, "ExciseRegister.html",
                      {'GDataItemCode': views.GDataItemCode, 'GDataCompanyCode': views.GDataCompanyCode,
                       'Exception': Exceptions})
    response = FileResponse(open(filepath, 'rb'))
    response['Content-Disposition'] = "attachment; filename=%s" % filepath
    return response