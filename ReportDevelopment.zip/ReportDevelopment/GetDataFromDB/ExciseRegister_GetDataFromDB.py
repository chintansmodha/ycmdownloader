
def ExciseRegister_GerData(LSCompany,LSChallanType,LSParty,LSCharges,LSAllCompanies,LSAllChallanTypes,
    LSAllParties,LSAllCharges,LSDepartment,LSItemType,LSChallanCategory,LSAllDepartments,LSAllItemTypes,LSAllChallanCategories,LDStartDate,
    LDEndDate,LSLotType):
    