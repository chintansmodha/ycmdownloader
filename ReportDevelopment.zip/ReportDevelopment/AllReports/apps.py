from django.apps import AppConfig


class AllreportsConfig(AppConfig):
    name = 'AllReports'
